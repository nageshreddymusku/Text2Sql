import pandas as pd
from datetime import datetime
import requests
import re
import urllib.parse
from main import *


def format(inpt):
    object_retriever = obj_index.as_retriever(similarity_top_k=2)
    query_or_string = inpt
    relevant_chunks = object_retriever.retrieve(query_or_string)

    schema_descriptions = []
    # Iterate over the relevant chunks (table schema objects) to build the schema description
    for relevant_chunk in relevant_chunks:
        table_name = relevant_chunk.table_name
        columns = sql_database.get_table_columns(table_name)
        column_names = [column["name"] for column in columns]

        # Build a schema description for the current table
        table_schema_description = f"Table: {table_name}\nColumns: " + ", ".join(
            column_names
        )
        schema_descriptions.append(table_schema_description)

    # Combine all table schema descriptions into a single schema string
    schema = "\n\n".join(schema_descriptions)

    # Assuming dialect and query_str are defined
    dialect = "MySQL"  # or the dialect you are using your query

    # Define the prompt as a string
    prompt_template = """
    # Task
    Generate a SQL query to answer the following question and the dialect is `{dialect}` and the question is:
    `{query_str}`

    # Database Schema
    The query will run on a database with the following schema:
    {schema}

    # SQL
    ```
    """

    # Format the prompt with the given variables
    formatted_prompt = prompt_template.format(
        dialect=dialect, schema=schema, query_str=query_or_string
    )
    return formatted_prompt
def extract_sql_query(output):
    # Join all generated texts (in case there are multiple outputs)
    full_text = " ".join(item["generated_text"] for item in output)
    match = full_text.split("# SQL\n```")

    # Use regular expression to find the SQL query part
    # This regex looks for the pattern "# SQL ``` SQL_QUERY ```"
    # and captures SQL_QUERY part
    return  match[1].strip()

API_URL = (
    "https://api-inference.huggingface.co/models/codellama/CodeLlama-34b-Instruct-hf"
)
headers = {"Authorization": "Bearer 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"}

def query(payload):
    payload = format(payload)
    response = requests.post(API_URL, headers=headers, json={"inputs": payload})
    ans = response.json()
    return extract_sql_query(ans)


# Initialize the components required for schema retrieval and query execution
# Assuming 'sql_database', 'object_retriever', and 'query_engine' are already initialized

# Initialize an empty DataFrame to store the results
columns = ["Question", "Response", "System Prompt", "Status of Execution", "Response Time", "SQL Query"]
results_df = pd.DataFrame(columns=columns)

notepad_file_path = "test cases.txt"  # Define the path to your Notepad file containing queries
excel_file_path = "query_execution_result1.xlsx"  # Define the path to your Excel file

# Read queries from the notepad file
with open(notepad_file_path, 'r') as notepad_file:
    queries = [line.strip() for line in notepad_file.readlines()]

for query_str in queries:
    formatted_prompt = format(query_str)
    start_time = datetime.now()

    try:
        # Execute the query
        res = query({"inputs": formatted_prompt})
        print(res)
        status = "Pass"
        sql_query = extract_sql_query(res)  # Extract SQL Query from the response
    except Exception as e:
        print(f"Error during query execution: {e}")
        import traceback
        traceback.print_exc()
        res = str(e)
        status = "Fail"
        sql_query = ''  # Set SQL Query to an empty string in case of failure

    # End the timer and calculate response time
    end_time = datetime.now()
    response_time = (end_time - start_time).total_seconds()

    # Append the results to the DataFrame
    new_row = pd.DataFrame([{
        "Question": query_str,
        "Response": res,
        "System Prompt": formatted_prompt,
        "Status of Execution": status,
        "Response Time": response_time,
        "SQL Query": sql_query
    }])
    results_df = pd.concat([results_df, new_row], ignore_index=True)

# Save the updated DataFrame to the Excel file after all queries
results_df.to_excel(excel_file_path, index=False)

print(f"Results have been saved to '{excel_file_path}'.")
