import torch

# import typing_extensions
# from typing_extenions import Iterator
import streamlit as st
import time
import json
from sqlalchemy import create_engine, text, inspect
from llama_index import SQLDatabase, ServiceContext
from llama_index.indices.struct_store.sql_query import NLSQLTableQueryEngine
from llama_index.objects import ObjectIndex, SQLTableNodeMapping, SQLTableSchema
from llama_index.indices.struct_store import SQLTableRetrieverQueryEngine
import openai
from llama_index.llms import HuggingFaceInferenceAPI
import requests
import re
import urllib.parse

# Database Configuration
# Database Configuration
db_config = {
     "host": "localhost",
     "user": "root",
     "password": "Nagesh123",
     "database": "farmerdatabase_schema",
 }

# Construct the connection string
# connection_string = f"mysql+mysqlconnector://{db_config['user']}:{db_config['password']}@{db_config['host']}:{db_config['port']}/{db_config['database']}"
connection_string = f"mysql+mysqlconnector://{db_config['user']}:{db_config['password']}@{db_config['host']}/{db_config['database']}"

# Create an engine instance
engine = create_engine(connection_string)
inspector = inspect(engine)
tables = inspector.get_table_names()

# Initializing necessary components
sql_database = SQLDatabase(engine, sample_rows_in_table_info=2)
from llama_index.llms import HuggingFaceInferenceAPI

inference_api = HuggingFaceInferenceAPI(
    model_name='cssupport/t5-small-awesome-text-to-sql',
    token="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",  # Optional, use if you need access to private models or increased rate limits
    task='sql-generation'  # Specify the task if you want Hugging Face to pick a recommended model
)

from llama_index.embeddings import HuggingFaceEmbedding
embed_model = HuggingFaceEmbedding(model_name="BAAI/bge-small-en-v1.5")

service_context = ServiceContext.from_defaults(llm=inference_api,embed_model=embed_model)
table_node_mapping = SQLTableNodeMapping(sql_database)
table_schema_objs = [(SQLTableSchema(table_name=table)) for table in tables]
obj_index = ObjectIndex.from_objects(table_schema_objs, table_node_mapping,service_context = service_context)

query_engine = SQLTableRetrieverQueryEngine(
    sql_database, obj_index.as_retriever(similarity_top_k=2),service_context = service_context
)


def format(inpt):
    object_retriever = obj_index.as_retriever(similarity_top_k=2)
    query_or_string = inpt
    relevant_chunks = object_retriever.retrieve(query_or_string)

    schema_descriptions = []
    # Iterate over the relevant chunks (table schema objects) to build the schema description
    for relevant_chunk in relevant_chunks:
        table_name = relevant_chunk.table_name
        columns = sql_database.get_table_columns(table_name)
        column_names = [column["name"] for column in columns]

        # Build a schema description for the current table
        table_schema_description = f"Table: {table_name}\nColumns: " + ", ".join(
            column_names
        )
        schema_descriptions.append(table_schema_description)

    # Combine all table schema descriptions into a single schema string
    schema = "\n\n".join(schema_descriptions)

    # Assuming dialect and query_str are defined
    dialect = "MySQL"  # or the dialect you are using your query

    # Define the prompt as a string
    prompt_template = """
    # Task
    Generate a SQL query to answer the following question and the dialect is `{dialect}` and the question is:
    `{query_str}`

    # Database Schema
    The query will run on a database with the following schema:
    {schema}

    # SQL
    ```
    """

    # Format the prompt with the given variables
    formatted_prompt = prompt_template.format(
        dialect=dialect, schema=schema, query_str=query_or_string
    )
    return formatted_prompt
import requests

API_URL = "https://api-inference.huggingface.co/models/codellama/CodeLlama-34b-Instruct-hf"
headers = {"Authorization": "Bearer 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"}

def query(payload):
	response = requests.post(API_URL, headers=headers, json=payload)
	return response.json()

output = query({
	"inputs": format(input),
})


import re

# Function to extract SQL query
def extract_sql_query(output):
    # Join all generated texts (in case there are multiple outputs)
    full_text = " ".join(item['generated_text'] for item in output)

    # Use regular expression to find the SQL query part
    # This regex looks for the pattern "# SQL ``` SQL_QUERY ```"
    # and captures SQL_QUERY part
    match = re.search(r'# SQL\s*```\s*([\s\S]+?)\s*```', full_text)

    if match:
        # Extract the SQL query from the matched group
        sql_query = match.group(1)
        return sql_query.strip()  # Remove leading and trailing whitespaces
    else:
        return "SQL query not found in the output."

# Extract SQL query from the output
sql_query = extract_sql_query(output)
print("Extracted SQL Query:")
print(sql_query)


import json

# Construct the payload for the API request
api_payload = {
    "inputs": formatted_prompt,
}

# Print the curl command
curl_command = f"curl -X POST -H 'Authorization: Bearer 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' -H 'Content-Type: application/json' -d '{json.dumps(api_payload)}' 'https://api-inference.huggingface.co/models/codellama/CodeLlama-34b-Instruct-hf'"
print("Generated Curl Command:")
print(curl_command)

# Send the API request
output = query(api_payload)

# Extract SQL query from the output
sql_query = extract_sql_query(output)
print("\nExtracted SQL Query:")
print(sql_query)





columns = ["Question", "Response", "System Prompt", "Status of Execution", "Response Time", "SQL Query"]
results_df = pd.DataFrame(columns=columns)

notepad_file_path = "test cases.txt"  # Define the path to your Notepad file containing queries
excel_file_path = "query_execution_result1.xlsx"  # Define the path to your Excel file

# Read queries from the notepad file
with open(notepad_file_path, 'r') as notepad_file:
    queries = [line.strip() for line in notepad_file.readlines()]

for query_str in queries:
    formatted_prompt = format(query_str)
    start_time = datetime.now()

    try:
        # Execute the query
        # res = query({"inputs": formatted_prompt})
        # print(res)
        api_payload = {
            "inputs": formatted_prompt,
        }
        output = query(api_payload)
        status = "Pass"
        sql_query = extract_sql_query(output)  # Extract SQL Query from the response
    except Exception as e:
        print(f"Error during query execution: {e}")
        import traceback
        traceback.print_exc()
        res = str(e)
        status = "Fail"
        sql_query = ''  # Set SQL Query to an empty string in case of failure

    # End the timer and calculate response time
    end_time = datetime.now()
    response_time = (end_time - start_time).total_seconds()

    # Append the results to the DataFrame
    new_row = pd.DataFrame([{
        "Question": query_str,
        "Response": res,
        "System Prompt": formatted_prompt,
        "Status of Execution": status,
        "Response Time": response_time,
        "SQL Query": sql_query
    }])
    results_df = pd.concat([results_df, new_row], ignore_index=True)

# Save the updated DataFrame to the Excel file after all queries
results_df.to_excel(excel_file_path, index=False)

print(f"Results have been saved to '{excel_file_path}'.")
