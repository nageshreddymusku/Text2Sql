import torch

# import typing_extensions
# from typing_extenions import Iterator
import streamlit as st
import time
import json
from sqlalchemy import create_engine, text, inspect
from llama_index import SQLDatabase, ServiceContext
from llama_index.indices.struct_store.sql_query import NLSQLTableQueryEngine
from llama_index.objects import ObjectIndex, SQLTableNodeMapping, SQLTableSchema
from llama_index.indices.struct_store import SQLTableRetrieverQueryEngine
import openai
from llama_index.llms import HuggingFaceInferenceAPI
import requests
import re
import urllib.parse

# Database Configuration
# Database Configuration
db_config = {
    "host": "localhost",
    "user": "root",
    "password": "Nagesh123",
    "database": "farmerdatabase_schema",
}

# Construct the connection string
# connection_string = f"mysql+mysqlconnector://{db_config['user']}:{db_config['password']}@{db_config['host']}:{db_config['port']}/{db_config['database']}"
connection_string = f"mysql+mysqlconnector://{db_config['user']}:{db_config['password']}@{db_config['host']}/{db_config['database']}"

# Create an engine instance
engine = create_engine(connection_string)
inspector = inspect(engine)
tables = inspector.get_table_names()

# Initializing necessary components
sql_database = SQLDatabase(engine, sample_rows_in_table_info=2)

inference_api = HuggingFaceInferenceAPI(
    model_name="cssupport/t5-small-awesome-text-to-sql",
    token="Bearer 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",
    # Optional, use if you need access to private models or increased rate limits
    task="sql-generation",  # Specify the task if you want Hugging Face to pick a recommended model
)

openai.api_key = "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"   # Replace with your actual OpenAI API key

service_context = ServiceContext.from_defaults(llm=inference_api)
table_node_mapping = SQLTableNodeMapping(sql_database)
table_schema_objs = [(SQLTableSchema(table_name=table)) for table in tables]
obj_index = ObjectIndex.from_objects(
    table_schema_objs, table_node_mapping, service_context=service_context
)

query_engine = SQLTableRetrieverQueryEngine(
    sql_database,
    obj_index.as_retriever(similarity_top_k=2),
    service_context=service_context,
)


def format(inpt):
    object_retriever = obj_index.as_retriever(similarity_top_k=2)
    query_or_string = inpt
    relevant_chunks = object_retriever.retrieve(query_or_string)

    schema_descriptions = []
    # Iterate over the relevant chunks (table schema objects) to build the schema description
    for relevant_chunk in relevant_chunks:
        table_name = relevant_chunk.table_name
        columns = sql_database.get_table_columns(table_name)
        column_names = [column["name"] for column in columns]

        # Build a schema description for the current table
        table_schema_description = f"Table: {table_name}\nColumns: " + ", ".join(
            column_names
        )
        schema_descriptions.append(table_schema_description)

    # Combine all table schema descriptions into a single schema string
    schema = "\n\n".join(schema_descriptions)

    # Assuming dialect and query_str are defined
    dialect = "MySQL"  # or the dialect you are using your query

    # Define the prompt as a string
    prompt_template = """
    # Task
    Generate a SQL query to answer the following question and the dialect is `{dialect}` and the question is:
    `{query_str}`

    # Database Schema
    The query will run on a database with the following schema:
    {schema}

    # SQL
    ```
    """

    # Format the prompt with the given variables
    formatted_prompt = prompt_template.format(
        dialect=dialect, schema=schema, query_str=query_or_string
    )
    return formatted_prompt




def extract_sql_query(output):
    # Join all generated texts (in case there are multiple outputs)
    full_text = " ".join(item["generated_text"] for item in output)
    match = full_text.split("# SQL\n```")

    # Use regular expression to find the SQL query part
    # This regex looks for the pattern "# SQL ``` SQL_QUERY ```"
    # and captures SQL_QUERY part
    return  match[1].strip()


API_URL = (
    "https://api-inference.huggingface.co/models/codellama/CodeLlama-34b-Instruct-hf"
)
headers = {"Authorization": "Bearer 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"}


def query(payload):
    payload = format(payload)
    # print(payload)
    response = requests.post(API_URL, headers=headers, json={"inputs": payload})
    # print("Response:",response)
    ans = response.json()
    return extract_sql_query(ans)


# payload = input("Enter query:")
# print("Final Answer\n",query(payload))


class ChatHistory:
    def __init__(self):
        self.history_file = "chat_history.json"
        self.max_length = 1  # Maximum length of the chat history
        self.clear_history()  # Clear the history on initialization

    def clear_history(self):
        self.history = []
        with open(self.history_file, "w") as file:
            json.dump(self.history, file, indent=4)

    def save_history(self):
        with open(self.history_file, "w") as file:
            json.dump(self.history, file, indent=4)

    def add_to_history(self, query, response):
        if len(self.history) >= self.max_length:
            self.history.pop(0)  # Remove the oldest entry
        self.history.append({"query": query, "response": response})
        self.save_history()

    def get_history(self):
        return self.history


# Create a global instance of ChatHistory
chat_history = ChatHistory()


def query_db(query_str):
    try:
        stored_chat_history = chat_history.get_history()
        chat_history_str = "\n".join(
            [
                f"User: {entry['query']}\nBot: {entry['response']}"
                for entry in stored_chat_history
            ]
        )
        prompt = query_str

        # Check if the user query is a delete request
        if "delete" in query_str.lower() and "record" in query_str.lower():
            # Provide custom response for delete request
            custom_response = "we restricted these queries to avoid SQL injection and security countermeasures"
            return "No sql query generated."

        response = query(prompt)
        # response_str = str(response)
        return response
    except Exception as e:
        print(f"Error occurred during query: {e}")
        error_response = "Please rephrase your question properly."
        return error_response


st.sidebar.title("Instructions")
st.sidebar.write("1. Type your queries in the input box below and press 'Enter'")
st.sidebar.write("2. Use the adjustable sidebar to explore an image and its caption.")
st.sidebar.write("3. Refer custom commands to understand the commands on how to query")

# Add a sidebar
st.sidebar.title("Sample Dataset")
image_path = "231.png"
caption = "Crop production sample dataset"
st.sidebar.image(image_path, caption=caption)

st.sidebar.title("Table Information")
st.sidebar.write("Crop Production: stores crop production data.")
st.sidebar.write("Final Rainfall: stores finalized rainfall data.")
st.sidebar.write("Final Temperature: stores finalized temperature data.")
st.sidebar.write("Crop Yield: stores crop yield data.")

st.sidebar.title("Custom Commands")

with st.sidebar:
    with st.expander("Commands", expanded=True):
        command_options = (
            "Describe the crop_yield table.",
            "Which crops had production greater than 30000 in Telangana?",
            "Which crops had production greater than 30000 in Assam?",
            "What is average pH value of rice?",
            "What is the yearly temperature of Bihar?",
            "What is the highest N value observed?",
            "What is the average N value of Maize?",
            "What is the Kharif temperature of Telangana?",
            "What is the highest yearly rainfall value?",
            "What is the total production of GroundNut in Andhra Pradesh?",
            "What is the total production of ragi in Andhra Pradesh?",
            "What is the average temperature of Karnataka?",
        )

        # Display custom commands as buttons
        for cmd in command_options:
            if st.button(cmd):
                st.session_state.enter_pressed = True
                st.text_input("You:", cmd)

st.title("Farmer Search")

# Initialize chat history
if "messages" not in st.session_state:
    st.session_state.messages = []

if "enter_pressed" not in st.session_state:
    st.session_state.enter_pressed = False

# Display chat messages from history on app rerun
for message in st.session_state.messages:
    with st.chat_message(message["role"]):
        st.markdown(message["content"])
        if "SQL_Query" in message:
            st.markdown(f"SQL Query: {message['SQL_Query']}")

# Define a unique key for the text input
user_input_key = "user_input"

# Check for Enter key press event
user_input = st.text_input("You:", key=user_input_key, value="")
if user_input:
    st.session_state.enter_pressed = False  # Reset the flag

    # Display spinner while querying the database
    with st.spinner("Querying database..."):
        # Simulate a delay (replace this with your actual database query)
        time.sleep(2)

        # Display user message in the chat message container
        st.chat_message("user").markdown(user_input)
        # Add user message to the chat history
        st.session_state.messages.append({"role": "user", "content": user_input})

        # Query the database with user input
        response_data = query_db(user_input)

        # Display assistant response in the chat message container
        with st.chat_message("assistant"):
            st.markdown(response_data)
        # Add assistant response to the chat history
        st.session_state.messages.append(
            {
                "role": "assistant",
                "content": response_data,
            }
        )
